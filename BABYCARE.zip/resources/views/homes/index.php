<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Welcome to Babycare Free online shopping website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="homes/https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="homes/https://fonts.googleapis.com/css?family=Fredericka+the+Great" rel="stylesheet">

    <link rel="stylesheet" href="homes/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="homes/css/animate.css">
    
    <link rel="stylesheet" href="homes/css/owl.carousel.min.css">
    <link rel="stylesheet" href="homes/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="homes/css/magnific-popup.css">

    <link rel="stylesheet" href="homes/css/aos.css">

    <link rel="stylesheet" href="homes/css/ionicons.min.css">
    
    <link rel="stylesheet" href="homes/css/flaticon.css">
    <link rel="stylesheet" href="homes/css/icomoon.css">
    <link rel="stylesheet" href="homes/css/style.css">
    
  </head>
  <body>
	  <div class="py-2 bg-primary">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
	    		<div class="col-lg-12 d-block">
		    		<div class="row d-flex">
			    		<div class="col-md-5 pr-4 d-flex topper align-items-center">
			    			<div class="icon bg-fifth mr-2 d-flex justify-content-center align-items-center"><span class="icon-map"></span></div>
						    <span class="text">198 West 21th Street, Kochin Kerala</span>
					    </div>
					    <div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon bg-secondary mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
						    <span class="text">babycaresupport@gmail.com</span>
					    </div>
					    <div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon bg-tertiary mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
						    <span class="text">+ 917034293986</span>
					    </div>
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco_navbar ftco-navbar-light" id="ftco-navbar">
	    <div class="container d-flex align-items-center">
	    	<a class="navbar-brand" href="index.php">BABY CARE</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item active"><a href="index.php" class="nav-link pl-0">Home</a></li>
	        	<li class="nav-item"><a href="#" class="nav-link">About Us</a></li>
	        	<li class="nav-item"><a href="home.login" class="nav-link">Login</a></li>
	        	<li class="nav-item"><a href="home.register" class="nav-link">Register</a></li>
	        	
	          <li class="nav-item"><a href="contact.html" class="nav-link">Contact</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image:url(homes/images/bg_1.jpg);">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-8 text-center ftco-animate">
            <h1 class="mb-4">Kids Are The Best <span>Explorers In The World</span></h1>
            <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3">Read More</a></p>
          </div>
        </div>
        </div>
      </div>

      <div class="slider-item" style="background-image:url(homes/images/bg_3.jpg);">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-8 text-center ftco-animate">
            <h1 class="mb-4">Big Sale <span>Offer</span></h1>
            <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3">Read More</a></p>
          </div>
        </div>
        </div>
      </div>

      <div class="slider-item" style="background-image:url(homes/images/bg_2.jpg);">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-8 text-center ftco-animate">
            <h1 class="mb-4">Perfect Choice<span> For Your Child</span></h1>
            <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3">Read More</a></p>
          </div>
        </div>
        </div>
      </div>
    </section>


  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="homes/js/jquery.min.js"></script>
  <script src="homes/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="homes/js/popper.min.js"></script>
  <script src="homes/js/bootstrap.min.js"></script>
  <script src="homes/js/jquery.easing.1.3.js"></script>
  <script src="homes/js/jquery.waypoints.min.js"></script>
  <script src="homes/js/jquery.stellar.min.js"></script>
  <script src="homes/js/owl.carousel.min.js"></script>
  <script src="homes/js/jquery.magnific-popup.min.js"></script>
  <script src="homes/js/aos.js"></script>
  <script src="homes/js/jquery.animateNumber.min.js"></script>
  <script src="homes/js/scrollax.min.js"></script>
  <script src="homes/https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="homes/js/google-map.js"></script>
  <script src="homes/js/main.js"></script>
    
  </body>
</html>