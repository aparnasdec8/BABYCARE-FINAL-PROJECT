<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <link rel="shortcut icon" href="img/favicon.png">

  <title>View Products</title>

  <!-- Bootstrap CSS -->
  <link href="merchant/css/bootstrap.min.css" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="merchant/css/bootstrap-theme.css" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="merchant/css/elegant-icons-style.css" rel="stylesheet" />
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="merchant/css/style.css" rel="stylesheet">
  <link href="merchant/css/style-responsive.css" rel="stylesheet" />


  <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
  <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->

    <!-- =======================================================
      Theme Name: NiceAdmin
      Theme URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
      Author: BootstrapMade
      Author URL: https://bootstrapmade.com
    ======================================================= -->
</head>

<body>
  <!-- container section start -->
  <section id="container" class="">
    <!--header start-->
    <header class="header dark-bg">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="index.html" class="logo">BABY<span class="lite">CARE</span></a>
      <!--logo end-->

      <div class="nav search-row" id="top_menu">
        <!--  search form start -->
        <ul class="nav top-menu">
          <li>
            <form class="navbar-form">
              <input class="form-control" placeholder="Search" type="text">
            </form>
          </li>
        </ul>
        <!--  search form end -->
      </div>

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">

          <!-- task notificatoin start -->
          
          <!-- alert notification end-->
          <!-- user login dropdown start-->
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <img alt="" src="admin/img/ammu.jpg">
                            </span>
                            <span class="username">Aparna Santhosh</span>
                            <b class="caret"></b>
                        </a>
            <ul class="dropdown-menu extended logout">
              <div class="log-arrow-up"></div>
              
              <li>
                <a href="userhome.userhome"><i class="icon_key_alt"></i> Log Out</a>
              </li>
              
            </ul>
          </li>
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->

    <!--sidebar start-->

    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="../dashboard">
                          <i class="icon_house_alt"></i>
                          <span>HOME</span>
                      </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>INVENTORY</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="addCategoryy"> Add Category</a></li>
             <li><a class="" href="addSubcategoryy"> Add Sub Category</a></li>
              <li><a class="" href="addBrandss">Add Brand</a></li>
			        
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span> PRODUCTS</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              
			        <li><a class="" href="/addProductss"> Item Listing</a></li>
            </ul>
          </li>
          
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>VIEW </span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
            <li><a class="" href="/admin.rusers">View Users</a></li>
              <li><a class="" href="/proview">View Product</a></li>
              <li><a class="" href="/viewcategoryy">View Category</a></li>
              <li><a class="" href="/viewbrandss">View Brands</a></li>
            </ul>
          </li> 
      </div>
    </aside>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-table"></i><b> view products</b></h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="../dashboard">Home</a></li>
              <li><i class="fa fa-table"></i>Users</li>
              <li><i class="fa fa-th-list"></i>View Registerd Users</li>
            </ol>
          </div>
        </div>
        <!-- page start-->
       
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Update Products             </header>

              <table class="table table-striped table-advance table-hover">
                <tbody>
                  <tr>
                  <th></i> Image</th>
                    <th></i> First Name</th>
                    
                    <th></i> Last Name</th>
                    
                    <th></i> Email-Id</th>
                    <th></i> Contact Number</th>
                    <th></i> Gender</th>
                    <th></i> Date Of Birth</th>
                    <th></i> Status</th>
                    <th></i> Action</th>
                  </tr>
                  <tr>
                  @foreach($user as $data)
                    
                    <td>
                  @if(!empty($data->photo))
                  <img src="upload/{{$data->photo}}" style="width:90px;">   
                  @endif
                  </td> 
                  <td>{{ $data->fname}}</td>
                    <!-- <td>{{ $data->photo}}</td> -->
                    <td>{{ $data->lname}}</td>
                    <td>{{ $data->email}}</td>
                    <td>{{ $data->phone}}</td>
                    <td>{{ $data->gender}}</td>
                    <td>{{ $data->dob}}</td>
                   
                  </td>
                  <td>
                  <?php
                 
                  $d=DB::select("select * from logins where id='$data->id'");
                  foreach($d as $t){
                    $tb=$t->status;
                  }
                      if($tb==1)
                      echo "Active";
                      else
                      echo "Inactive";
                      ?>
                      </td>
                      
                      <td>
                      <a href="{{url('block/'.$data->id)}}">
                      <?php
                      if($tb=='1'){
                        echo "Disable";
                      }
                     
                      else{
                        echo "Enable";
                      }
                    
                      ?>
                      </a></td>
                    <td>
                    <div class="btn-group">
                      
                      <!-- <a class="btn btn-danger" href="block/{id}"><i class="icon_close_alt2"></i>Disable</a> -->
                    </div>
                  </tr>
                  
                  
                </tbody>
                @endforeach
              </table>
            </section>
          </div>
        </div>
        <!-- page end-->
      </section>
    </section>
    <!--main content end-->
    <div class="text-right">
      <div class="credits">
          <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
          -->
          
        </div>
    </div>
  </section>
  <!-- container section end -->
  <!-- javascripts -->
  <script src="admin/js/jquery.js"></script>
  <script src="admin/js/bootstrap.min.js"></script>
  <!-- nicescroll -->
  <script src="admin/js/jquery.scrollTo.min.js"></script>
  <script src="admin/js/jquery.nicescroll.js" type="text/javascript"></script>
  <!--custome script for all page-->
  <script src="admin/js/scripts.js"></script>


</body>

</html>





<!-- <div class="inner-block">
<center><fieldset style="width:50%">
 <h2><center><font color="#FF6347"><b>USERS LIST</b></font></center></h2>   		

<table>
<table border="1">
            <tr>
                 <th><center><b>First Name</b></center></th><br>
                 <th><b>Last Name</b></th>
                <th><b>Email-Id</b></th>
                 <th><b>Contact Number</b></th>
                 <th><b>Gender</b></th>
                  <th><b>Date Of Birth</b></th>
                  
                
            </tr>
            @foreach ($user as $data)
            <tr>
                <td><font align="rignt">{{$data->fname}}</font></td>
                <td>{{$data->lname}}</td>
                <td>{{$data->email}}</td>
                <td>{{$data->phone}}</td>
                <td>{{$data->gender}}</td>
                <td>{{$data->dob}}</td>
                
                 
            </tr>
           
            @endforeach
        </table>
        -->
        </body>

</html>