<html>
<head></head>
<body></body>
<div style="background-color: white;width: 500px;height: 50px;border: 2px solid white;padding-left: 5px;margin: 500px;margin-top:50px;">
     <h1 align="center"><b><font color="#dc3545">Add category</font></b></h1>

      <form  action="{{route('admin.store')}}" method="post">
        {{@csrf_field()}}
     </br>

<label for="t1"><b><font color="#dc3545">Category</font></b></label><br>
      <input type="text" class="form-control" placeholder="District Name" name="category" required />
    
    <br>
    
  <td colspan="2"> <input style="background-color:#dc3545;text-decoration:none;color:white;margin-left:200px;margin-top:50px;" type="submit" name="submit"  /></td>
  </tr>
</table>

</form>

</div>
