<html>
<head>babycare</head>
<body>
<?php
  $unm = session()->get('email');
  $d=DB::select("select id from logins where email='$unm'");
  foreach($d as $dp)
  {
  $un=$dp->id;
}
 $st=DB::select("select * from products,orders where orders.p_id=products.p_id and orders.id='$un'and  orders.status=3"); 
 
 $stt=DB::select("select * from orders where orders.id='$un'"); 
 $count = 1;
?>

<div class="container">
    <div class="row">
        <div class="col-xs-12">
        <br>
        <br>
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                
            </div>
            <?php
  $unm = session()->get('email');
  $d=DB::select("select id from logins where email='$unm'");
  foreach($d as $dp)
  {
  $un=$dp->id;
}
 $st=DB::select("select * from products,orders where orders.p_id=products.p_id and orders.id='$un' and  orders.mode_of_payment='CreditCard' "); 
 
 $count = 251;
?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="text-center"><strong>Order summary</strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive" id="tab">
                        <table class="table table-condensed">
                           
                            <?php $total = 0; ?>
 
                            @foreach($st as $row)
                        
                            <thead>
                       
                            <tr><td><h6>Invoice for purchase #{{$row->p_id}}</td></tr></h6>
                                <tr>
                                    <td><strong>Item Name</strong></td>

                                    <td class="text-center"><strong>Item Price</strong></td>
                                    <td class="text-center"><strong>Item Quantity</strong></td>
                                    <td class="text-right"><strong>Total</strong></td>
                                </tr>
                            </thead>

                            <?php $total += $row->totalprice; ?>
                            <tbody>
                                <tr>
                                    <td>{{$row->pname}}</td>
                                    <td class="text-center">{{$row->price}}</td>
                                    <td class="text-center">{{$row->quantity}}</td>
                                    <td class="text-right">Rs.{{$row->totalamount}}</td>
                                </tr>

                                <tr>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow text-center"><strong>Status</strong></td>

                                    <td class="emptyrow text-right">{{$row->p_status}}</td>
                                </tr>

                                <tr>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow text-center"><strong>Delivery Date</strong></td>
                                    <td class="emptyrow text-right">{{$row->delivery_date}}</td>
                                </tr>

                                @endforeach
                            </tbody>
                        </table>
                        
                    <input type="button" onclick='createPDF()' value="Download">
                    <br>
                   <p class="right"> Total Purchase Amount Rs.{{ $total }}</p>
                   
                   </body>
                   </html>