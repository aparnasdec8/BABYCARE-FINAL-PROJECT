<!doctype html>
<html lang="en">
<head>

   
      <title>Babycare online shopping</title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="Toys Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
      <script>
         addEventListener("load", function () {
         	setTimeout(hideURLbar, 0);
         }, false);
         
         function hideURLbar() {
         	window.scrollTo(0, 1);
         }
      </script>
      <!--//meta tags ends here-->
      <!--booststrap-->
      <link href="../home/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
      <!--//booststrap end-->
      <!-- font-awesome icons -->
      <link href="../home/css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all">
      <!-- //font-awesome icons -->
      <!--Shoping cart-->
      <link rel="stylesheet" href="../home/css/shop.css" type="text/css" />
      <!--//Shoping cart-->
      <!--price range-->
      <link rel="stylesheet" type="text/css" href="../home/css/jquery-ui1.css">
      <!--//price range-->
      <!--stylesheets-->
      <link href="../home/css/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//stylesheets-->
      <link href="../home///fonts.googleapis.com/css?family=Sunflower:500,700" rel="stylesheet">
      <link href="../home///fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myDIV ").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
  
    <meta charset="UTF-8">
    <title>Download your purchase details</title>

    <style type="text/css">
        @page {
            margin: 0px;
        }
        body {
            margin: 0px;
        }
        * {
            font-family: Verdana, Arial, sans-serif;
        }
        a {
            color: #fff;
            text-decoration: none;
        }
        table {
            font-size: x-small;
        }
        tfoot tr td {
            font-weight: bold;
            font-size: x-small;
        }
        .invoice table {
            margin: 15px;
        }
        .invoice h3 {
            margin-left: 15px;
        }
        .information {
            background-color: #60A7A6;
            color: #FFF;
        }
        .information .logo {
            margin: 5px;
        }
        .information table {
            padding: 10px;
        }
        .button{
            background-color:#60A7A6;
        }
    </style>

</head>
<body>

<div class="header-outs" id="home">
      <div class="header-bar">
         <div class="info-top-grid">
            <div class="info-contact-agile">
               <ul>
                  <li>
                     <span class="fas fa-phone-volume"></span>
                     <p>+91 7510614142</p>
                  </li>
                  <li>
                     <span class="fas fa-envelope"></span>
                     <p><a href="mailto:info@example.com">babycaresupport@gmail.com.com</a></p>
                  </li>
                  <li>
                  </li>
               </ul>
            </div>
         </div>
         <div class="container-fluid">
            <div class="hedder-up row">
               <div class="col-lg-3 col-md-3 logo-head">
                  <h1><a class="navbar-brand" href="index.html">Baby-Care</a></h1>
               </div>
               <div class="col-lg-5 col-md-6 search-right">
                  <form class="form-inline my-lg-0">
                     <input id="myInput" class="form-control mr-sm-2" type="search" placeholder="Search">
                     <button class="btn" type="submit">Search</button>
                  </form>
               </div>
               <div class="col-lg-4 col-md-3 right-side-cart">
               <h6><b> welcome!     {{session()->get('email')}}</b></h6>
						   
                  <div class="cart-icons">
                     <ul>
                        <li>
                           <span class="far fa-heart"></span>
                        </li>
                        <li>
                           <p><a href="userhome.userhome">::Logout</a></p>
						   </li>
                        
                       
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <?php
        $datass=DB::select("select * from categories");
        
        ?>
         <nav class="navbar navbar-expand-lg navbar-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
               <ul class="navbar-nav ">
                  <li class="nav-item ">
                     <a class="nav-link" href="../home.home">Home <span class="sr-only">(current)</span></a>
                  </li>
                  
                  <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Products By Category
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        @isset($datass)
    
                        @foreach($datass as $data)
    <a class="nav-link "  value="{{$data->c_id}}"  href="{{url('categorypurchase/'.$data->c_id)}}" style="width:300px;">{{$data->category}}</a>
    @endforeach
    @endisset
                           
                        </div>
                     </li>
                  <li class="nav-item active">
                     <a href="/shopnow" class="nav-link">Shop Now</a>
                  </li>
                  
                  <li class="nav-item">
                     <a href="../home.about" class="nav-link">About Us</a>
                  </li>
                  
                 
                  <li class="nav-item">
                     <a href="../home.service" class="nav-link">Service</a>
                  </li>
               </ul>
            </div>
         </nav>
      </div>
	  </div>

      <div class="inner_page-banner one-img">
      </div>
      <!--//banner -->
      <!-- short -->
      <div class="using-border py-3">
         <div class="inner_breadcrumb  ml-4">
            <ul class="short_ls">
               <li>
                  <a href="home.home">Home</a>
                  <span>/ /</span>
               </li>
               <li>Shop Now</li>
            </ul>
         </div>
      </div>



<?php
  $unm = session()->get('email');
  $d=DB::select("select id from logins where email='$unm'");
  foreach($d as $dp)
  {
  $un=$dp->id;

}
$oid=explode(',',$insertids);
foreach($oid as $oids){


 $st=DB::select("select * from products,orders where orders.p_id=products.p_id and orders.id='$un' and  orders.mode_of_payment='CreditCard' and orders.oid='$oids'"); 

 $count = 251;

?>
 
<div class="information">
    <table width="100%">
        <tr>
            <td align="left" style="width: 40%;">
                
               

            </td>
            <!-- <td align="center">
                <img src="/path/to/logo.png" alt="Logo" width="64" class="logo"/>
            </td> -->
            <td align="right" style="width: 40%;">

               
            </td>
        </tr>

    </table>
</div>

@foreach($st as $row)
<br/>

<div class="invoice" id="record">
   
    <table width="100%">

    
    <?php $total = 0; ?>
 
      
  
      
        <thead>
        <tr>
            <th width="300px;">Item Name</th>
            <th width="400px;">Item Price</th>
            <th width="300px;">Item Quantity</th>
            <th width="300px;">Status</th>
            <th width="300px;">Delivery Date</th>
            
        </tr>
        </thead>
        <tbody>
        
          <h3>Product Id#{{$row->p_id}}-0SKU </h3>
        <tr>
            <td width="200px;"height="50px;">{{$row->pname}}</td>
            <td width="100px;">{{$row->price}}</td>
            <td >{{$row->quantityy}}</td>
            <td width="300px;">{{$row->p_status}}</td>
           <td width="300px;"> {{$row->delivery_date}}</td>
            

        </tr>
       
				
        
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td> 
        </tr>
       
      

         <tfoot>
        
         @endforeach
       <?php } ?>
        <tr> 
        @foreach($st as $row)
            <td colspan="1"></td>
            <td align ="right" height="100px;">Total Purchase Amount Rs.       {{$row->totalamount }}</td>
            <!-- <td align="left" class="gray"></td> -->
          
        </tr>
        @endforeach
        </tbody>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="button" type="submit" onclick="createPDF()" style="width:150px; height:50px;">Download</button></td>
        
        </tfoot>
      
        
    </table>
    
    <!-- <input type="button" onclick='createPDF()' value="Download"> -->
</div>

<div class="information" style="position: absolute; bottom: 0;">

<script>
    function createPDF()
    {
        var sTable = document.getElementById('record').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 17px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CREATE A WINDOW OBJECT.
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Ticket Details</title>');   // <title> FOR PDF HEADER.
        win.document.write(style);          // ADD STYLE INSIDE THE HEAD TAG.
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(sTable);         // THE TABLE CONTENTS INSIDE THE BODY TAG.
        win.document.write('</body></html>');

        win.document.close();   // CLOSE THE CURRENT WINDOW.

        win.print();    // PRINT THE CONTENTS.

    }
    </script>

    <!-- <table width="1400px;">
        <tr>
            <td align="left" style="width: 50%;">
                &copy; {{ date('Y') }} {{ config('app.url') }} - All rights reserved.
            </td>
            <td align="right" style="width: 10%;">
                BabyCare
            </td>
        </tr>

    </table> -->
   
</div>


<script src='../home/js/jquery-2.2.3.min.js'></script>
      <!--//js working-->
      <!-- cart-js -->
       <script src="../home/js/minicart.js"></script>
      <script>
         toys.render();
         
         toys.cart.on('toys_checkout', function (evt) {
         	var items, len, i;
         
         	if (this.subtotal() > 0) {
         		items = this.items();
         
         		for (i = 0, len = items.length; i < len; i++) {}
         	}
         });
      </script>
      <!-- //cart-js -->
		<!-- price range (top products) -->
		<script src="../home/js/jquery-ui.js"></script>
		<script>
			//<![CDATA[ 
			$(window).load(function () {
				$("#slider-range").slider({
					range: true,
					min: 0,
					max: 9000,
					values: [50, 6000],
					slide: function (event, ui) {
						$("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
					}
				});
				$("#amount").val("$" + $("#slider-range").slider("values", 0) + " - $" + $("#slider-range").slider("values", 1));

			}); //]]>
		</script>
		<!-- //price range (top products) -->

      <!-- start-smoth-scrolling -->
       <script src="../home/js/move-top.js"></script>
      <script src="../home/js/easing.js"></script>
      <script>
         jQuery(document).ready(function ($) {
         	$(".scroll").click(function (event) {
         		event.preventDefault();
         		$('html,body').animate({
         			scrollTop: $(this.hash).offset().top
         		}, 900);
         	});
         });
      </script>
      <!-- start-smoth-scrolling -->
      <!-- here stars scrolling icon -->
      <script>
         $(document).ready(function () {
         
         	var defaults = {
         		containerID: 'toTop', // fading element id
         		containerHoverID: 'toTopHover', // fading element hover id
         		scrollSpeed: 1200,
         		easingType: 'linear'
         	};
         
         
         	$().UItoTop({
         		easingType: 'easeOutQuart'
         	});
         
         });
      </script>
      <!-- //here ends scrolling icon -->
      <!--bootstrap working-->
      <script src="../home/js/bootstrap.min.js"></script>
      <!-- //bootstrap working-->

</body>
</html>