<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
   @if(session()->has('email'))
   <!DOCTYPE html>
<html lang="zxx">
   <head>
      <title>Babycare online shopping</title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="Toys Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
      <script>
         addEventListener("load", function () {
         	setTimeout(hideURLbar, 0);
         }, false);
         
         function hideURLbar() {
         	window.scrollTo(0, 1);
         }
      </script>
      <!--//meta tags ends here-->
      <!--booststrap-->
      <link href="home/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
      <!--//booststrap end-->
      <!-- font-awesome icons -->
      <link href="home/css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all">
      <!-- //font-awesome icons -->
      <!--Shoping cart-->
      <link rel="stylesheet" href="home/css/shop.css" type="text/css" />
      <!--//Shoping cart-->
      <!--price range-->
      <link rel="stylesheet" type="text/css" href="home/css/jquery-ui1.css">
      <!--//price range-->
      <!--stylesheets-->
      <link href="home/css/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//stylesheets-->
      <link href="home///fonts.googleapis.com/css?family=Sunflower:500,700" rel="stylesheet">
      <link href="home///fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


      <meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
 <meta name="keywords" content="Square Profile Widget a Flat Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
 
<link href="user/css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all">
<link href="user/css/style.css" rel='stylesheet' type='text/css' />

<!--webfonts-->

<link href="user///fonts.googleapis.com/css?family=Roboto:400,500,700,900" rel="stylesheet">
<!--//webfonts-->
<style>
      h6{
         color:blue;
      }
      </style>



<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myDIV ").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
   </head>
   <body>
   <div class="header-outs" id="home">
         <div class="header-bar">
            <div class="info-top-grid">
               <div class="info-contact-agile">
                  <ul>
                     <li>
                        <span class="fas fa-phone-volume"></span>
                        <p>+91 7510614142</p>
                     </li>
                     <li>
                        <span class="fas fa-envelope"></span>
                        <p><a href="mailto:info@example.com">babycaresupport@gmail.com</a></p>
                     </li>
                     <li>
                     </li>
                  </ul>
               </div>
            </div>
            
            <div class="container-fluid">
               <div class="hedder-up row">
                  <div class="col-lg-3 col-md-3 logo-head">
                     <h1><a class="navbar-brand" href="index.html">Baby-Care</a></h1>
                  </div>
                  <div class="col-lg-5 col-md-6 search-right">
                     <form class="form-inline my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search">
                        <button class="btn" type="submit">Search</button>
                     </form>
                  </div>
                  <div class="col-lg-4 col-md-3 right-side-cart">
                  <h6><b> welcome!     {{session()->get('email')}}</b></h6>
						   
                     <div class="cart-icons">
                        <ul>
                           <li>
                              <span class="far fa-heart"></span>
                           </li>
                           
                     <li>
                           <p><a href="userhome.userhome">::Logout</a></p>
						   </li>
                           <li class="toyscart toyscart2 cart cart box_1">
                              <form action="user.check" method="get" class="last">
                                
                                 <button class="top_toys_cart" type="submit" name="submit" value="">
                                 <span class="fas fa-cart-arrow-down"></span>
                                 </button>
                              </form>
                           </li>
						   
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         <?php
        $datass=DB::select("select * from categories");
        
        ?>
         <nav class="navbar navbar-expand-lg navbar-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
               <ul class="navbar-nav ">
                  <li class="nav-item ">
                     <a class="nav-link" href="home.home">Home <span class="sr-only">(current)</span></a>
                  </li>
                  
                  <!-- <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Product
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        @isset($datass)
    
                        @foreach($datass as $data)
    <a class="nav-link "  value="{{$data->c_id}}"  href="{{url('..categorypurchase/'.$data->c_id)}}" style="width:300px;">{{$data->category}}</a>
    @endforeach
    @endisset
                           
                        </div>
                     </li> -->
                  <li class="nav-item ">
                     <a href="/shopnow" class="nav-link">Shop Now</a>
                  </li>
                  
                  <li class="nav-item">
                     <a href="home.about" class="nav-link">About Us</a>
                  </li>
                  
                 
                  <li class="nav-item">
                     <a href="home.service" class="nav-link">Service</a>
                  </li>
               </ul>
            </div>
         </nav>
      </div>
	  </div>
      <!--//headder-->
      <!-- banner -->
      <div class="inner_page-banner one-img">
      </div>
      <!--//banner -->
      <!-- short -->
      <div class="using-border py-3">
         <div class="inner_breadcrumb  ml-4">
            <ul class="short_ls">
               <li>
                  <a href="home.home">Home</a>
                  <span>/ /</span>
               </li>
               <li>Profile</li>
            </ul>
         </div>
      </div>
      <!-- //short-->
      <!--show Now-->  
      <!--show Now-->


           
						   <!-- <li>
                              <button type="button" data-toggle="modal" data-target="#exampleModal1"> <span class="far fa-user"></span></button>
                           </li> --> 
                           <!-- <li class="toyscart toyscart2 cart cart box_1">
                              <form action="/logins_login" method="post" class="last">
                                 <input type="hidden" name="cmd" value="_cart">
                                 <input type="hidden" name="display" value="1">
                                 <button class="top_toys_cart" type="submit" name="submit" value="">
                                 <span class="fas fa-cart-arrow-down"></span>
                                 </button>
                              </form>
                           </li> -->
						   
                        </ul>
                     </div>
                  </div>
               </div>
            </div>

	<!-- main -->
	@method('PATCH')
 @foreach($result as  $value)

 <form action="user.viewprofile/{{$value->email}}" method="post">
		<div class="center-container">
		
			<div class="inner_page-banner one-img">
			
				
				<h1>My Profile  </h1>
			<div class="profile" >
	<div class="wrap">
		<div class="profile-main"style="width:2000px;">
			<div class="profile-pic wthree" >
				<img src="{{asset('/upload/'.$value->photo)}}" style="width:250px; height:150px;" alt="" >
				<h3>{{$value->fname}}</h3>
<div class="w3ls-agile-left" >
<!---728x90---> 
				
				<ul class="address">
									<li>
										<ul class="address-text">
											<li><b>LAST NAME</b></li>
											<li>: </li>
											<li> <span class="w3">{{$value->lname}}</span></li>
										</ul>
									</li>
                                    <li>
										<ul class="address-text">
											<li><b>GENDER </b></li>
											<li>: </li>
											<li><span class="w3">{{$value->gender}}</span></li>
										</ul>
									</li>
									
									<li>
										<ul class="address-text">
											<li><b>D.O.B </b></li>
											<li>: </li>
											<li> <span class="w3">{{$value->dob}}</span></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>PHONE </b></li>
											<li>: </li>
											<li> <span class="w3">{{$value->phone}}</span></li>
										</ul>
									</li>
									<li>
										<ul class="address-text">
											<li><b>EMAIL </b></li>
											<li>: </li>
											<li> <span class="w3">{{$value->email}}</span></li>
										</ul>
									</li>

				</ul>
                </form>
@endforeach
                             
<div class="clear"></div>
			</div>
         <br>
         <br>
			                 
		</div>
	</div>
</div>
	
			<!--footer-->
	<div class="footer-w3">
		
	</div>
	<!--//footer-->
			
		</div>
	</div>
	<!-- //main -->

<script  src="user/js/jquery.min.v3.js"></script>
		<script src="user/js/jquery.circlechart.js"></script>
<script>
$('.demo-1').percentcircle();

$('.demo-2').percentcircle({
animate : false,
diameter : 100,
guage: 3,
coverBg: '#000',
bgColor: '#ff0000',
fillColor: '#000',
percentSize: '50px',
percentWeight: 'normal'
});
		
			
	</script>
	<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>	

 
</body>
@endif
</html>